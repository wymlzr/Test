﻿#include <QDebug>
#include <QLabel>
#include <QDateTime>
#include <QLibrary>
#include <QFileDialog>
#include "mainwindow.h"
#include "ui_mainwindow.h"

#pragma execution_character_set("utf-8")

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    m_pBlankWidget = NULL;
    m_pMyWidget = NULL;
    m_pModel = NULL;
    m_pWriteFileThread = NULL;
    m_pThread = NULL;
    ui->setupUi(this);
    setWindowTitle("界面程序-李忠仁-2023.9.15");

    InitForm();
    InitTable();
    InitTreeTable();
    InitComm();

    //把自定义Widget添加主界面
    m_pMyWidget = new MyWidget;
    QHBoxLayout* pLayout = new QHBoxLayout(ui->widget_2);
    pLayout->addWidget(m_pMyWidget);


}

MainWindow::~MainWindow()
{
    delete ui;
    if(m_pBlankWidget != NULL)
    {
        delete m_pBlankWidget;
        m_pBlankWidget = NULL;
    }
}
//初始化界面
void MainWindow::InitForm()
{
    //文件
    QAction* pFileAct = new QAction;
    pFileAct->setText("文件");
    ui->menuBar->addAction(pFileAct);
    //视图
    QAction* pViewAct = new QAction;
    pViewAct->setText("视图");
    ui->menuBar->addAction(pViewAct);
    //文件
    QAction* pSetAct = new QAction;
    pSetAct->setText("设置");
    ui->menuBar->addAction(pSetAct);
    //文件
    QAction* pHelpAct = new QAction;
    pHelpAct->setText("帮助");
    ui->menuBar->addAction(pHelpAct);

    connect(ui->menuBar, &QMenuBar::triggered, this, &MainWindow::slot_MenuBarClick);

    //初始化工具栏
    ui->mainToolBar->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
    //后退工具栏
    QString strPath = QApplication::applicationDirPath() + "/Image/prev.png";
    QAction* pToolAct1 = new QAction;
    pToolAct1->setIcon(QIcon(strPath));
    pToolAct1->setText("后退");
    ui->mainToolBar->addAction(pToolAct1);
    //前进工具栏
    strPath = QApplication::applicationDirPath() + "/Image/next.png";
    QAction* pToolAct2 = new QAction;
    pToolAct2->setIcon(QIcon(strPath));
    pToolAct2->setText("前进");
    ui->mainToolBar->addAction(pToolAct2);
    //搜索
    strPath = QApplication::applicationDirPath() + "/Image/search.png";
    QAction* pToolAct3 = new QAction;
    pToolAct3->setIcon(QIcon(strPath));
    pToolAct3->setText("搜索");
    ui->mainToolBar->addAction(pToolAct3);
    //保存
    strPath = QApplication::applicationDirPath() + "/Image/save.png";
    QAction* pToolAct4 = new QAction;
    pToolAct4->setIcon(QIcon(strPath));
    pToolAct4->setText("保存");
    ui->mainToolBar->addAction(pToolAct4);
    //删除
    strPath = QApplication::applicationDirPath() + "/Image/delete.png";
    QAction* pToolAct5 = new QAction;
    pToolAct5->setIcon(QIcon(strPath));
    pToolAct5->setText("删除");
    ui->mainToolBar->addAction(pToolAct5);
    connect(ui->mainToolBar, &QToolBar::actionTriggered, this, &MainWindow::slot_ToolBarClick);

    //状态栏
    QLabel* pVerLabel = new QLabel;
    pVerLabel->setText("版本号 1.0");
    QLabel* pTestLabel1 = new QLabel;
    pTestLabel1->setText("状态测试1");
    QLabel* pTestLabel2 = new QLabel;
    pTestLabel2->setText("状态测试2");
    ui->statusBar->addWidget(pVerLabel);
    ui->statusBar->addPermanentWidget(pTestLabel1);
    ui->statusBar->addPermanentWidget(pTestLabel2);

}

void MainWindow::InitComm()
{
    //服务端
    m_TcpServer = new QTcpServer(this);
    m_TcpServer->listen(QHostAddress("127.0.0.1"),5000);
    connect(m_TcpServer, &QTcpServer::newConnection,[=]
    {
        m_TcpSocket = m_TcpServer->nextPendingConnection();
    });

    //客户端
    m_TcpClient = new QTcpSocket(this);
    m_TcpClient->connectToHost(QHostAddress("127.0.0.1"),5000);
    connect(m_TcpClient,&QTcpSocket::readyRead,[=]
    {
        QByteArray array = m_TcpClient->readAll();
        slot_showLog(array);
    });
}
//初始化表格
void MainWindow::InitTable()
{
    QStringList head;
    head<<"序号"<<"频率(MHz)"<<"带宽(kHz)"<<"幅度(dBm)"<<"样式";
    ui->tableWidget->setRowCount(8);
    ui->tableWidget->setColumnCount(5);
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tableWidget->setHorizontalHeaderLabels(head);
    ui->tableWidget->verticalHeader()->hide();
    //默认数据
    for(int i = 0; i < ui->tableWidget->rowCount(); i++)
    {
        ui->tableWidget->setItem(i,0,new QTableWidgetItem(QString("%1").arg(i+1)));
        ui->tableWidget->setItem(i,1,new QTableWidgetItem(QString("%1").arg(60 + i*30)));
        ui->tableWidget->setItem(i,2,new QTableWidgetItem(QString("%1").arg(5 + i*3)));
        ui->tableWidget->setItem(i,3,new QTableWidgetItem(QString("%1").arg(-80 + i*5)));
        ui->tableWidget->setItem(i,4,new QTableWidgetItem(QString("%1").arg(qrand()%5)));
    }
    for(int i = 0; i < ui->tableWidget->rowCount(); i++)
    {
        for(int j = 0; j < ui->tableWidget->columnCount(); j++)
        {
            ui->tableWidget->item(i,j)->setTextAlignment(Qt::AlignCenter);
        }
    }
}

void MainWindow::InitTreeTable()
{
    ui->treeView->setEditTriggers(QAbstractItemView::NoEditTriggers);
    m_pModel = new QStandardItemModel(ui->treeView);
    QStringList head;
    head<<"序号"<<"频率(MHz)"<<"带宽(kHz)"<<"幅度(dBm)"<<"样式";
    m_pModel->setHorizontalHeaderLabels(head);
    for(int i = 0; i < 8;i++)
    {
        QStandardItem* pChildItem = new QStandardItem(QString("%1").arg(i+1));
        m_pModel->appendRow(pChildItem);
        //子节点
        QList<QStandardItem*> itemList;
        QStandardItem* pNumItem = new QStandardItem(QString("%1").arg(i+1));
        QStandardItem* pFreqItem = new QStandardItem(QString("%1").arg(qrand()%50));
        QStandardItem* pBWItem = new QStandardItem(QString("%1").arg(qrand()%50));
        QStandardItem* pFDItem = new QStandardItem(QString("%1").arg(qrand()%50));
        QStandardItem* pTypeItem = new QStandardItem(QString("%1").arg(qrand()%50));
        itemList.append(pNumItem);
        itemList.append(pFreqItem);
        itemList.append(pBWItem);
        itemList.append(pFDItem);
        itemList.append(pTypeItem);
        pChildItem->appendRow(itemList);
    }
    ui->treeView->setModel(m_pModel);
}

void MainWindow::SelectItem(QStandardItem* pItem)
{
    int iRowCount = pItem->rowCount();
    int iColCount = pItem->columnCount();
    if(pItem->hasChildren())
    {
        for(int i = 0; i < iRowCount; i++)
        {
            for(int j = 1; j < iColCount;j++)
            {
                if(pItem->text().toInt() < 25)
                {
                    pItem->setText("0");
                }
                SelectItem(pItem->child(i,j));
            }
        }
    }
}

void MainWindow::slot_showLog(QString str)
{
    ui->textBrowser->append(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss zzz")+": "+str);
}
//菜单栏点击
void MainWindow::slot_MenuBarClick(QAction *pAction)
{
    if(pAction == NULL)
        return;
    if(pAction->text().compare("视图") == 0)
    {
        if(m_pBlankWidget == NULL)
        {
            m_pBlankWidget = new QWidget(NULL);
            m_pBlankWidget->setAttribute(Qt::WA_QuitOnClose,false);
        }
        m_pBlankWidget->showNormal();
    }
}
//工具栏点击
void MainWindow::slot_ToolBarClick(QAction *pAction)
{
    if(pAction == NULL)
        return;
    slot_showLog("你点击了工具栏的"+pAction->text()+"按钮");

}

//点击表格倒序
void MainWindow::on_pushButton_clicked()
{
    static bool bFlag = false;
    bFlag = !bFlag;
    if(bFlag)
    {
        ui->tableWidget->sortByColumn(0, Qt::DescendingOrder);
    }
    else
    {
        ui->tableWidget->sortByColumn(0, Qt::AscendingOrder);
    }
}
 //点击树形表格小于25变为0
void MainWindow::on_pushButton_2_clicked()
{
    int iCount = m_pModel->rowCount();
    for(int i = 1; i < iCount; i++)
    {
        SelectItem(m_pModel->item(i));
    }
}
//点击树形表格过滤单行
void MainWindow::on_pushButton_3_clicked()
{
    int iCount = m_pModel->rowCount();
    for(int i = iCount; i >= 1; i--)
    {
        if(i % 2 == 0)
        {
            m_pModel->removeRow(i-1);
        }
    }
}

void MainWindow::timerEvent(QTimerEvent *e)
{
    if(e->timerId() == m_iTimer)
    {
        QString str = QString("%1").arg((char)qrand()%100);
        m_TcpSocket->write(str.toLatin1());
    }
}
//点击定时发送数据
void MainWindow::on_pushButton_4_clicked()
{
    m_iTimer = startTimer(500);
}
//停止定时发送数据
void MainWindow::on_pushButton_5_clicked()
{
    killTimer(m_iTimer);
}

void MainWindow::on_pushButton_6_clicked()
{
//    QString path = QFileDialog::getOpenFileUrl(this,"选择路径",NULL);
    QString path = QFileDialog::getExistingDirectory(this,"选择路径",QDir::currentPath());
    if(m_pWriteFileThread == NULL)
    {
        m_pWriteFileThread = new WriteFileThread;
        connect(m_pWriteFileThread,&WriteFileThread::signal_ShowLog,this, &MainWindow::slot_showLog);
    }
    if(m_pThread == NULL)
    {
        m_pThread = new QThread;
    }
    m_pWriteFileThread->SetPath(path+"/hello.txt");
    m_pWriteFileThread->OpenFile();
    m_pWriteFileThread->moveToThread(m_pThread);
    m_pThread->start();
}
