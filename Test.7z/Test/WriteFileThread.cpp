﻿#include "WriteFileThread.h"
#include <QTextStream>
#pragma execution_character_set("utf-8")

WriteFileThread::WriteFileThread(QObject *parent) : QObject(parent)
{
    m_strFilePath = "";
}

void WriteFileThread::SetPath(QString strPath)
{
    m_strFilePath = strPath;
}

void WriteFileThread::OpenFile()
{
    m_FIle.setFileName(m_strFilePath);
    m_FIle.open(QIODevice::WriteOnly);
    m_iTimer = startTimer(500);
}

void WriteFileThread::timerEvent(QTimerEvent *e)
{
    if(e->timerId() == m_iTimer)
    {
        static int iCount = 0;
        iCount++;
        if(!m_FIle.isOpen())
        {
            killTimer(m_iTimer);
            emit signal_ShowLog("writer error");
            return;
        }

        QTextStream stream(&m_FIle);
        QString str = QString("你好，“文件”");
        stream << str;

        if(iCount == 100)
        {
            killTimer(m_iTimer);
            iCount = 0;
            m_FIle.close();
            m_FIle.setFileName("");
            m_strFilePath = "";
            emit signal_ShowLog("writer Finash");
        }
    }
}

