﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QVBoxLayout>
#include <QTreeView>
#include <QStandardItemModel>
#include "MyWidget.h"
#include <QTcpServer>
#include <QTcpSocket>
#include <QThread>
#include "WriteFileThread.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    QStandardItemModel*     m_pModel;
    MyWidget*               m_pMyWidget;            //自定义界面
    QWidget*                m_pBlankWidget;         //空白界面
    int                     m_iTimer;               //定时器

    QTcpServer*             m_TcpServer;            //服务端
    QTcpSocket*             m_TcpSocket;            //服务端Socket
    QTcpSocket*             m_TcpClient;            //客户端

    WriteFileThread*        m_pWriteFileThread;     //读取文件
    QThread*                m_pThread;
private:
    //初始化界面
    void InitForm();
    //初始化通信
    void InitComm();
    //初始化表格
    void InitTable();
    //初始化树形表格
    void InitTreeTable();
    //查询数据是否小于25
    void SelectItem(QStandardItem* pItem);

public slots:
    //打印日志
    void slot_showLog(QString str);
    //菜单栏点击
    void slot_MenuBarClick(QAction* pAction);
    //工具栏点击
    void slot_ToolBarClick(QAction* pAction);
private slots:
    //点击表格倒序
    void on_pushButton_clicked();
    //点击树形表格小于25变为0
    void on_pushButton_2_clicked();
    //点击树形表格过滤单行
    void on_pushButton_3_clicked();
    //点击定时发送数据
    void on_pushButton_4_clicked();
    //停止发送数据
    void on_pushButton_5_clicked();
    //打开文件写数据
    void on_pushButton_6_clicked();

protected:
    void timerEvent(QTimerEvent* e);
private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
