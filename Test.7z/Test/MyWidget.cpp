﻿#include "MyWidget.h"
#include <QPainter>
#include <QApplication>

MyWidget::MyWidget(QWidget *parent) : QWidget(parent)
{

}

void MyWidget::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing,true);
    painter.drawImage(rect(),QImage(QApplication::applicationDirPath()+"/Image/th.jpg"));
}
