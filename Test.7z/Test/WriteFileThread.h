﻿#ifndef WriteFileThread_H
#define WriteFileThread_H

#include <QObject>
#include <QTimerEvent>
#include <QFile>

class WriteFileThread : public QObject
{
    Q_OBJECT
public:
    explicit WriteFileThread(QObject *parent = nullptr);

private:
    int             m_iTimer;
    QFile           m_FIle;
    QString         m_strFilePath;
public:
    //设置路径
    void SetPath(QString strPath);
    //打开文件
    void OpenFile();
protected:
    void timerEvent(QTimerEvent* e);
signals:
    void signal_ShowLog(QString);
public slots:
};

#endif // WriteFileThread_H
